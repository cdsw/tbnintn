#!/bin/sh
/home/pi/modules/serverComm
