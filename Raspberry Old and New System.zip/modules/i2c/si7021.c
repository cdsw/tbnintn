#include <stdio.h>
#include <stdlib.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <fcntl.h>



int main(int argc, char **argv)
{
	//Initiate I2C bus
	int device;
	char *bus = "/dev/i2c-1";
	if((device = open(bus, O_RDWR)) < 0) 
	{
		printf("Failed to open the bus. \n");
		exit(1);
	}
	//Get I2C device
	ioctl(device, I2C_SLAVE, SI7021_ADDR);

	if(argv[1][0] == 'h')
	{
		printf("%3.4f RH", getHumidity(device));
	}
	else if(argv[1][0] == 't')
	{
		printf("%3.4f C", getTemperature(device));
	}
	return 0;
}