// Made with help from controlEverything.com.

#include <stdio.h>
#include <stdlib.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <fcntl.h>

void main() 
{
	// Create I2C bus
	int file;
	char *bus = "/dev/i2c-1";
	if ((file = open(bus, O_RDWR)) < 0) 
	{
		printf("Failed to open the bus. \n");
		exit(1);
	}
	// Get I2C device, ADS1115 I2C address is customized to 0x49
	ioctl(file, I2C_SLAVE, 0x49);

	// Select configuration register(0x01)
	// AINP = AIN0 and AINN = AIN1, +/- 6.144V (0x80)
	// Continuous conversion mode, 860 SPS(0xE3)
	char config[3] = {0};
	config[0] = 0x01;
	config[1] = 0x80;
	config[2] = 0xE3;
	write(file, config, 3);
	sleep(1);

	// Read 2 bytes of data from register(0x00)
	// raw_adc msb, raw_adc lsb
	char reg[1] = {0x00};
	write(file, reg, 1);
	char data[2]={0};
	if(read(file, data, 2) != 2)
	{
		printf("Error : Input/Output Error \n");
	}
	else 
	{
		// Convert the data
		int raw_adc = (data[0] * 256 + data[1]);
		float voltage = raw_adc * 5.14 /27468.0;
		float current = voltage * 625 / 3000 + 0.1092;

		// Output data to screen
		printf("%f V \n", voltage);
	}
}