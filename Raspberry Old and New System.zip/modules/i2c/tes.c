#include <stdio.h>

void main(){
	FILE *fp;
	unsigned ts;
	float h, t;
	fp = fopen("sensorData.txt", "r");;
	while(fscanf(fp, "[%u;%f;%f]\n", &ts, &h, &t) != 0){
		printf("[%u;%f;%f]\n", &ts, &h, &t);
	}
}