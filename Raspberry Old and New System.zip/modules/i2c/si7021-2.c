//Made with help from www.controleverything.com

#include <stdio.h>
#include <stdlib.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <time.h>

#define HUMIDITY_CMD 0xF5 //No-hold master mode
#define TEMPERATURE_CMD 0xF3 //No-hold master mode
#define SI7021_ADDR 0x40 //Address of slave

float getHumidity(int device_temp)
{
	//Send humidity reading command
	char config[1] = {HUMIDITY_CMD};
	write(device_temp, config, 1);
	sleep(0.001);

	//Read 2 bytes of humidity data, humidity msb, humidity lsb
	char data[2] = {0};
	if(read(device_temp, data, 2) != 2)
	{
		printf("Error : Input/output Error \n");
		return -1;
	}
	else
	{
		//Convert the data
		float humidity = (((data[0] * 256 + data[1]) * 125.0) / 65536.0) - 6;

		//Return humidity
		return humidity;
	}	
}

float getTemperature(int device_temp)
{
	//Send humidity reading command
	char config[1] = {TEMPERATURE_CMD};
	write(device_temp, config, 1); 
	sleep(0.001);

	//Read 2 bytes of temperature data (temp msb, temp lsb)
	char data[2] = {0};
	if(read(device_temp, data, 2) != 2)
	{
		printf("Error : Input/output Error \n");
		return -1;
	}
	else
	{
		//Convert the data
		float cTemp = (((data[0] * 256 + data[1]) * 175.72) / 65536.0) - 46.85;

		//Return temperature
		return cTemp;	
	}
}

int main(int argc, char **argv)
{
	//Initiate I2C bus
	int device_temp;
	char *bus = "/dev/i2c-1";
	if((device_temp = open(bus, O_RDWR)) < 0) 
	{
		printf("Failed to open the bus. \n");
		exit(1);
	}
	//Get I2C device_temp
	ioctl(device_temp, I2C_SLAVE, SI7021_ADDR);
	float outTemp = 0, outHum = 0;

	if(argv[1][0] == 'h')
	{
		outTemp = getHumidity(device_temp);
		printf("%3.4f RH\n", outTemp);
	}
	else if(argv[1][0] == 't')
	{
		outHum = getTemperature(device_temp);
		printf("%3.4f C\n", outHum);
	}
	else if(argv[1][0] == 'b')
	{
		outTemp = getHumidity(device_temp);
		printf("%3.4f RH\n", outTemp);
		outHum = getTemperature(device_temp);
		printf("%3.4f C\n", outHum);	
	}

	unsigned timestamp = (unsigned)time(NULL);

	FILE *sensorData;
	sensorData = fopen("sensorData.txt", "a");
	fprintf(sensorData, "[%u;%f;%f]\n", timestamp, outTemp, outHum);
	return 0;
}