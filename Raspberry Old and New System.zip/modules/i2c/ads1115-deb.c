// Made with help from controlEverything.com.

#include <stdio.h>
#include <stdlib.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <fcntl.h>

int sum = 0;
int count = 0;
void main() 
{
	// Create I2C bus
	int device_adc;
	char *bus = "/dev/i2c-1";
	if ((device_adc = open(bus, O_RDWR)) < 0) 
	{
		printf("Failed to open the bus. \n");
		exit(1);
	}
	// Get I2C device, ADS1115 I2C address is customized to 0x49
	ioctl(device_adc, I2C_SLAVE, 0x49);

	while(1){
	// Select configuration register(0x01)
	// AINP = AIN0 and AINN = AIN1, +/- 6.144V (0x80)
	// Continuous conversion mode, 860 SPS(0xE3)
	char config[3] = {0};
	config[0] = 0x01;
	config[1] = 0x80;
	config[2] = 0xE3;
	write(device_adc, config, 3);
	sleep(1);

	// Read 2 bytes of data from register(0x00)
	// raw_adc msb, raw_adc lsb
	char reg[1] = {0x00};
	write(device_adc, reg, 1);
	char data[2]={0};
	if(read(device_adc, data, 2) != 2)
	{
		printf("Error : Input/Output Error \n");
	}
	else 
	{
		// Convert the data
		int raw_adc = (data[0] * 256 + data[1]);
		if(raw_adc > 32767){
			raw_adc -= 65536;
		}
		sum += raw_adc;
		count += 1;

		// Output data to screen
		printf("%d | %d \n", raw_adc, sum/count);
	}
	}
}