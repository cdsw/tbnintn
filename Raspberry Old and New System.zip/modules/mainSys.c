//Mosquitto Subscribe/Publish

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <mosquitto.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>

//Server Identities
#define HOST "broker.hivemq.com"
#define PORT 1883
#define TOPIC "tigaresiiot"

#define TEMPERATURE_CMD 0xF3 //No-hold master mode
#define SI7021_ADDR 0x40 //Address of slave

int device_temp;

float getTemperature(int device_temp)
{
	//Send temperature reading command
	char config[1] = {TEMPERATURE_CMD};
	write(device_temp, config, 1); 
	sleep(1);

	//Read 2 bytes of temperature data (temp msb, temp lsb)
	char data[2] = {0};
	if(read(device_temp, data, 2) != 2)
	{
		printf("Error : Input/output Error \n");
		return -1;
	}
	else
	{
		//Convert the data
		float cTemp = (((data[0] * 256 + data[1]) * 175.72) / 65536.0) - 46.85;

		//Return temperature
		return cTemp;	
	}
}

float getCurrent(){
	return 3.0;
}

//Message Event
void messageArrived(struct mosquitto *m, void *obj, 
	const struct mosquitto_message *message)
{
	//Do command
	char msg[50];
	strcpy(msg, (char*) message->payload);
	printf("Message: %s\n", msg);

	//Response for each command 
	if (msg[0] == '*' && strlen(msg) > 1)
	{
		char resp[50]; //MQTT response
		char resp_lirc[25]; //LIRC response
		if (msg[1] == 'd')
		{ //down temperature
			int targetTemp = (msg[2] - 48) * 10 + msg[3] - 48;
			//LIRC
			sprintf(resp_lirc, "irsend SEND_ONCE MY_REMOTE TE%d", targetTemp);
			system(resp_lirc);
			//MQTT
			sprintf(resp, "ON;%f;%d;%f;%%", getTemperature(device_temp), targetTemp, getCurrent());
			printf("DOWNTEMP\n");
		} 
		else if (msg[1] == 'u') 
		{ //up temperature
			int targetTemp = (msg[2] - 48) * 10 + msg[3] - 48;
			//LIRC
			sprintf(resp_lirc, "irsend SEND_ONCE MY_REMOTE TE%d", targetTemp);
			system(resp_lirc);
			//MQTT
			sprintf(resp, "ON;%f;%d;%f;%%", getTemperature(device_temp), targetTemp, getCurrent());
			printf("UPTEMP\n");
		} 
		else if (msg[1] == '0') 
		{ //power off
			system("irsend SEND_ONCE MY_REMOTE PWOF"); //LIRC
			sprintf(resp, "OFF; ; ; ;%%");
			printf("OFF\n");
		} 
		else if (msg[1] == '1') 
		{ //power on
			int targetTemp = (msg[2] - 48) * 10 + msg[3] - 48;
			system("irsend SEND_ONCE MY_REMOTE PWON"); //LIRC
			sprintf(resp, "ON;%f;%d;%f;%%", getTemperature(device_temp), targetTemp, getCurrent());

			printf("ON\n");
		} 
		else if (msg[1] == 'r') 
		{ //read sensors
			if(msg[2] == '1')
			{
				int targetTemp = (msg[3] - 48) * 10 + msg[4] - 48;
				sprintf(resp, "ON;%f;%d;%f;%%", getTemperature(device_temp), targetTemp, getCurrent());
			} 
			else if (msg[2] == '0')
			{
				sprintf(resp, "OFF;%f; ; ;%%", getTemperature(device_temp));
			}
			printf("READ\n");
		}

		//Back response/acknowledge part
		int pub = mosquitto_publish(m, NULL, TOPIC, strlen(resp), resp, 0, false);
		if (pub)
		{
			printf("Can't publish message\n");
			exit(-1);
		}

	}
}

int main(int argc, char **argv){


	//I2C initialization for temperature sensor
	char *bus = "/dev/i2c-1";
	if((device_temp = open(bus, O_RDWR)) < 0) 
	{
		printf("Failed to open the bus. \n");
		exit(1);
	}
	//Get I2C device for temperature
	ioctl(device_temp, I2C_SLAVE, SI7021_ADDR);

	//Mosquitto library initialization
	struct mosquitto *m = NULL;
	mosquitto_lib_init();
        //Client initialization (NULL = random)
	m = mosquitto_new(NULL, true, NULL);
	if (!m)
	{
		printf("Can't initialize Mosquitto\n");
		exit(-1);
	}

	//Connect to server
	int conn = mosquitto_connect(m, HOST, PORT, 0);
	if (conn)
	{
		printf("Can't connect to server\n");
		exit(-1);
	}

	//Subscribe for messages
	int sub = mosquitto_subscribe(m, NULL, TOPIC, 0);
	if (sub)
	{
		printf("Cannot subscribe\n");
		exit(-1);
	}

	srand(time(NULL));
	//Locate event handler
	mosquitto_message_callback_set(m, messageArrived);

	//Loop for getting messages
	mosquitto_loop_forever(m, -1, 1);

	//Exit if needed
	mosquitto_destroy(m);
	mosquitto_lib_cleanup();

	return 0;
}