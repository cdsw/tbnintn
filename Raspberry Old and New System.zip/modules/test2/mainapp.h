#ifndef MAINAPP_H
#define MAINAPP_H

#include <QObject>
#include <QFuture>
#include <QQueue>
#include <QMutex>
#include "i2c.h"

class MainApp : public QObject
{
    Q_OBJECT
public:
    MainApp();
    ~MainApp();

    void timerEvent(QTimerEvent* e);

    void execThread();

    int setTemperature;

    static MainApp* Singleton;

    QQueue<QByteArray> queCommands;
    QMutex queLOCK;

private:

    static I2C i2c_device;
    struct mosquitto *m = NULL;

    bool runFlag;
    QFuture<void> ptrThread;
};

#endif // MAINAPP_H
