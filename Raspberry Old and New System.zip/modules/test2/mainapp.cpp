#include "mainapp.h"
#include "i2c.h"
#include <QtConcurrent/QtConcurrent>
#include <QDebug>

//serialComm.c
#include <stdio.h>
#include <stdlib.h>
#include <curl/curl.h>
#include <time.h>

//mainSys.c
#include <mosquitto.h>

//Server Identities
#define HOST "broker.hivemq.com"
#define PORT 1883
#define TOPIC "tigaresiiot"

I2C MainApp::i2c_device;

MainApp* MainApp::Singleton = nullptr;

//Event on MQTT message arrival
void messageArrived(struct mosquitto *m, void *obj,
                    const struct mosquitto_message *message)
{
    qDebug() << (char*)message->payload;
    //Do command
    char msg[10];
    strcpy(msg, (char*) message->payload);
    printf("Message: %s\n", msg);

    QByteArray rcv;
    char* ptr = static_cast<char*>(message->payload);
    for (int i = 0; i < message->payloadlen; i++){
        rcv.append(*ptr++);
    }

    MainApp::Singleton->queLOCK.lock();
    MainApp::Singleton->queCommands.enqueue(rcv);
    MainApp::Singleton->queLOCK.unlock();
}


MainApp::MainApp()
{
    setTemperature = 16;

    i2c_device = I2C();
    //Mosquitto library initialization
    mosquitto_lib_init();
    //Client initialization (NULL = random)
    m = mosquitto_new(NULL, true, NULL);
    if (!m)
    {
        printf("Can't initialize Mosquitto\n");
        exit(-1);
    }

    //Connect to server
    int conn = mosquitto_connect(m, HOST, PORT, 0);
    if (conn)
    {
        printf("Can't connect to server\n");
        exit(-1);
    }

    //Subscribe for messages
    int sub = mosquitto_subscribe(m, NULL, TOPIC, 0);
    if (sub)
    {
        printf("Cannot subscribe\n");
        exit(-1);
    }

    srand(time(NULL));
    //Locate event handler
    mosquitto_message_callback_set(m, messageArrived);

    //Loop for getting messages
    mosquitto_loop_start(m);

    startTimer(100, Qt::CoarseTimer);
}

MainApp::~MainApp(){
    //Exit if needed
    mosquitto_loop_stop(m, true);
    mosquitto_destroy(m);
    mosquitto_lib_cleanup();
}

void MainApp::timerEvent(QTimerEvent* e)
{
    if(queCommands.length() == 0) return;

    queLOCK.lock();
    QByteArray rcv = queCommands.dequeue();
    queLOCK.unlock();

    QByteArrayList vals = rcv.split(';');

    //Response for each command
    if (vals[0] == "SS" && vals.length() >= 2)
    {
        int targetTemp;
        char resp[35]; //MQTT response
        char resp_lirc[35]; //LIRC response

        //Get sensor readings
        float temp_ = MainApp::i2c_device.getTemperature();
        float curr_ = MainApp::i2c_device.getCurrent();
        if (vals[1] == "ON")
        {
            targetTemp = vals[2].toInt();
            if(targetTemp > 0)
                setTemperature = targetTemp;
            //LIRC
            sprintf(resp_lirc, "irsend SEND_ONCE MY_REMOTE PWON");
            sprintf(resp_lirc, "irsend SEND_ONCE MY_REMOTE TE%d", setTemperature);
            system(resp_lirc);
            //MQTT
            sprintf(resp, "DD;ON;%f;%d;%f", temp_, setTemperature, curr_);
            qDebug() << "ON" << targetTemp;

        }
        else if (vals[1] == "OFF")
        {
            targetTemp = vals[2].toInt();
            if(targetTemp > 0)
                setTemperature = targetTemp;
            //LIRC
            sprintf(resp_lirc, "irsend SEND_ONCE MY_REMOTE PWOF");
            system(resp_lirc);
            //MQTT
            sprintf(resp, "DD;OFF; ; ; ");
            qDebug() << "OFF" << targetTemp;

        }
        else if (vals[1] == "r")
        { //read sensors

            targetTemp = vals[2].toInt();
            if(targetTemp > 0)
                setTemperature = targetTemp;

            if (curr_ > 0)
                sprintf(resp, "DD;ON;%f;%d;%f", temp_, setTemperature, curr_);
            else
                sprintf(resp, "DD;OFF;%f; ; ", temp_);
            qDebug() << "READ" << targetTemp;

        }

        //Back response/acknowledge part
        int pub = mosquitto_publish(m, NULL, TOPIC, strlen(resp), resp, 0, false);
        if (pub)
        {
            printf("Can't publish message\n");
            exit(-1);
        }
    }
}


void MainApp::execThread(){
    runFlag = true;

    while(runFlag)
    {

    }
}
