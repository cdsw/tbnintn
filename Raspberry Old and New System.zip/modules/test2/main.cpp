#include <QCoreApplication>
#include <iostream>

#include <unistd.h>
#include <QThread>
#include "mainapp.h"

using namespace std;

int main(int argc, char *argv[]){

    QCoreApplication a(argc, argv);
    MainApp app;
    MainApp::Singleton = &app;
    return a.exec();
}
