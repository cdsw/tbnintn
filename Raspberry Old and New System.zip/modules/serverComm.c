#include <stdio.h>
#include <stdlib.h>
#include <curl/curl.h>
#include <time.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <fcntl.h>

#define TEMPERATURE_CMD 0xF3 //No-hold master mode
#define SI7021_ADDR 0x40 //Address of slave


int device;
float getTemperature(int device)
{
	//Send temperature reading command
	char config[1] = {TEMPERATURE_CMD};
	write(device, config, 1); 
	sleep(1);

	//Read 2 bytes of temperature data (temp msb, temp lsb)
	char data[2] = {0};
	if(read(device, data, 2) != 2)
	{
		printf("Error : Input/output Error \n");
		return -1;
	}
	else
	{
		//Convert the data
		float cTemp = (((data[0] * 256 + data[1]) * 175.72) / 65536.0) - 46.85;

		//Return temperature
		return cTemp;	
	}
}

float getCurrent(){
	return 3.0;
}

int main()
{
	//I2C initialization for temperature sensor
	char *bus = "/dev/i2c-1";
	if((device = open(bus, O_RDWR)) < 0) 
	{
		printf("Failed to open the bus. \n");
		exit(1);
	}
	//Get I2C device
	ioctl(device, I2C_SLAVE, SI7021_ADDR);

	//CURL initialization
	curl_global_init( CURL_GLOBAL_ALL );
	CURL * myHandle;
	CURLcode result; // We’ll store the result of CURL’s webpage retrieval, for simple error checking.
	myHandle = curl_easy_init ( ) ;

	//Get timestamp
	unsigned timestamp = (unsigned)time(NULL);
	
	char* input[100];
	float temp, curr;
	temp = getTemperature(device);

	curr = getCurrent();
	sprintf(input, "http://tbniot.000webhostapp.com/add_data.php?ts=%u&cur=%f&temp=%f", timestamp, curr, temp);
	curl_easy_setopt(myHandle, CURLOPT_URL, input);
	result = curl_easy_perform( myHandle );
	curl_easy_cleanup( myHandle );
return 0;
}