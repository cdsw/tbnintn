#include <iostream>
#include <errno.h>
#include <wiringPiSPI.h>
#include <unistd.h>

using namespace std;

// channel is the wiringPi name for the chip select (or chip enable) pin.
// Set this to 0 or 1, depending on how it's connected.
static const int CHANNEL = 0;

int main(){
   int fd, result;
   unsigned char buffer[4];

   // Configure the interface.
   // CHANNEL insicates chip select,
   // 500000 indicates bus speed.
   fd = wiringPiSPISetup(CHANNEL, 50000);

   cout << "Init result: " << fd << endl;

/*   //Configure chip Ch1, +AIN7, -AIN9
   buffer[0] = 0xE9;
   buffer[1] = 0x00;
   buffer[2] = 0x09;
   wiringPiSPIDataRW(CHANNEL, buffer, 3);

   //Config 1, default
   buffer[2] = 0x19;
   buffer[1] = 0x08;
   buffer[0] = 0x60;
   wiringPiSPIDataRW(CHANNEL, buffer, 3);

   //Filter default
   buffer[3] = 0x21;
   buffer[2] = 0x06;
   buffer[1] = 0x01;
   buffer[0] = 0x80;
   wiringPiSPIDataRW(CHANNEL, buffer, 4);

   //Offset default
   buffer[3] = 0x29;
   buffer[2] = 0x80;
   buffer[1] = 0x00;
   buffer[0] = 0x00;
   wiringPiSPIDataRW(CHANNEL, buffer, 4);

   //Gain
   buffer[3] = 0x29;
   buffer[2] = 0x80;
   buffer[1] = 0x00;
   buffer[0] = 0x00;
   wiringPiSPIDataRW(CHANNEL, buffer, 4);

   //Control
   buffer[2] = 0x01;
   buffer[1] = 0x00;
   buffer[0] = 0x00;
   wiringPiSPIDataRW(CHANNEL, buffer, 3);*/

   // Check ID
   buffer[0] = 0x45;
   result = wiringPiSPIDataRW(CHANNEL, &buffer[0], 1);
   printf("RESULT:");
   int i;
   for(i = 0; i<result; i++){
      printf("0x%02X \n", buffer[i]);
   }

   return 0;
}