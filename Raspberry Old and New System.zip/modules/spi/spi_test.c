/*
 * Simple Linux wrapper for access to /dev/spidev
 * File: "spi_test.c" - test module
 */

//-----------------------------------------------------------------------------
#include "spi.h"
#include <wiringPi.h>
//-----------------------------------------------------------------------------
#define SPI_DEVICE "/dev/spidev0.0"
//#define SPI_DEVICE "/dev/spidev1.0"
//-----------------------------------------------------------------------------
int main()
{
  spi_t spi;
  char buf[1024];

  wiringPiSetup();
  pinMode(6, OUTPUT);

  int retv = spi_init(&spi,
                      SPI_DEVICE, // filename like "/dev/spidev0.0"
                      0,          // SPI_* (look "linux/spi/spidev.h")
                      8,          // bits per word (usually 8)
                      1000000);   // max speed [Hz]

  printf(">>> spi_init() return %d\n", retv);

  buf[0] = 0b01000101;

  digitalWrite(10, 0);
  retv = spi_write(&spi, buf, 1);
  digitalWrite(10, 1);
  printf(">>> spi_write(0x45) return %d\n", buf[0]);

  digitalWrite(10, 0);
  retv = spi_read(&spi, buf, 1);
  digitalWrite(10, 1);
  printf(">>> spi_read(0x45) return %d\n", buf[0]);

  spi_free(&spi);

  return 0;
}

/*** end of "spi_test.c" file ***/

