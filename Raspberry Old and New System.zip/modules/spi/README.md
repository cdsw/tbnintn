# A user-space example program to comunicate using spidev on Linux

Sorces based on http://linux-sunxi.org/SPIdev

