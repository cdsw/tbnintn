#! /bin/sh

make clean


