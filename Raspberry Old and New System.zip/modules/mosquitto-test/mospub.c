//Mosquitto Publish

#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <mosquitto.h>
#include <string.h>

//Server Identities
#define HOST "broker.hivemq.com"
#define PORT 1883
#define TOPIC "tigaresiiot"

int main (int argc, char **argv){
	struct mosquitto *m = NULL;
	//Mosquitto library initialization
	mosquitto_lib_init();
    	//Client initialization (NULL = random)
	m = mosquitto_new(NULL, true, NULL);
	if (!m){
		printf("Can't initialize Mosquitto\n");
		exit(-1);
	}

	//Connect to server
	int conn = mosquitto_connect(m, HOST, PORT, 0);
	if (conn){
		printf("Can't connect to server\n");
		exit(-1);
	}

	//Publish the message
	int pub = mosquitto_publish(m, NULL, TOPIC, strlen(argv[1]), argv[1], 0, false);
	if (pub){
		printf("Can't publish message\n");
		exit(-1);
	}

	//Sleep to avoid OS problem
	sleep(1);

	//Exit
	mosquitto_disconnect(m);
	mosquitto_destroy(m);
	mosquitto_lib_cleanup();

	return 0;
}