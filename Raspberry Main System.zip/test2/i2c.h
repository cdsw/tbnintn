#ifndef I2C_H
#define I2C_H


class I2C
{
public:
    I2C();
    ~I2C();
    float getTemperature();
    float getCurrent();
private:
    int device;
};

#endif // I2C_H
