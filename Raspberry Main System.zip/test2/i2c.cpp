#include "i2c.h"
#include <linux/i2c-dev.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <QThread>

#define TEMPERATURE_CMD 0xF3 //No-hold master mode
#define SI7021_ADDR 0x40 //Address of temperature sensor
#define ADS1115_ADDR 0x49 //Address of ADC
#define WAIT_TIME 400

I2C::I2C()
{
    //I2C initialization for temperature sensor
    char *bus = "/dev/i2c-1";
    if((this->device = open(bus, O_RDWR)) < 0)
    {
        printf("Failed to open the bus. \n");
        exit(1);
    }
}

I2C::~I2C(){

}

float I2C::getTemperature()
{
    //Get I2C device for temperature
    ioctl(this->device, I2C_SLAVE, SI7021_ADDR);

    //Send temperature reading command
    char config[1] = {TEMPERATURE_CMD};
    write(this->device, config, 1);
    QThread::msleep(WAIT_TIME);

    //Read 2 bytes of temperature data (temp msb, temp lsb)
    char data[4] = {0};
    if(read(this->device, data, 2) != 2)
    {
        printf("Error : Input/output Error \n");
        return -1;
    }
    else
    {
        //Convert the data
        float cTemp = (((data[0] * 256 + data[1]) * 175.72) / 65536.0) - 46.85;

        //Return temperature
        return cTemp;
    }
}

float I2C::getCurrent(){
    // Get I2C device, ADS1115 I2C address is customized to 0x49
    ioctl(this->device, I2C_SLAVE, ADS1115_ADDR);

    // Select configuration register(0x01)
    // AINP = AIN0 and AINN = AIN1, +/- 6.144V (0x80)
    // Continuous conversion mode, 860 SPS(0xE3)
    char config[3] = {0};
    config[0] = 0x01;
    config[1] = 0x80;
    config[2] = 0xE3;
    write(this->device, config, 3);
    QThread::msleep(WAIT_TIME);

    // Read 2 bytes of data from register(0x00)
    // raw_adc msb, raw_adc lsb
    char reg[1] = {0x00};
    write(this->device, reg, 1);
    char data[2]={0};
    if(read(this->device, data, 2) != 2)
    {
        printf("Error : Input/Output Error \n");
        return -1;
    }
    else
    {
        // Convert the data
        float voltage = (data[0] * 256 + data[1]);
        voltage = voltage * 5.14/27468.0;
        float current = voltage * 625 / 3000.0 + 0.1092;

        return current;
    }
}
