#ifndef MAINAPP_H
#define MAINAPP_H

#include <QObject>
#include <QFuture>
#include "i2c.h"

class MainApp : public QObject
{
    Q_OBJECT
public:
    MainApp();
    ~MainApp();

    void timerEvent(QTimerEvent* e);

    void execThread();
    static I2C i2c_device;

private:
    bool runFlag;
    QFuture<void> ptrThread;
};

#endif // MAINAPP_H
