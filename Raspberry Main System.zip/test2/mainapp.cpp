#include "mainapp.h"
#include "i2c.h"
#include <QtConcurrent/QtConcurrent>
#include <QDebug>

//serialComm.c
#include <stdio.h>
#include <stdlib.h>
#include <curl/curl.h>
#include <time.h>

//mainSys.c
#include <mosquitto.h>

//Server Identities
#define HOST "broker.hivemq.com"
#define PORT 1883
#define TOPIC "tigaresiiot"

I2C MainApp::i2c_device;

//Event on MQTT message arrival
void messageArrived(struct mosquitto *m, void *obj,
    const struct mosquitto_message *message)
{
    qDebug() << (char*)message->payload;
    //Do command
    char msg[10];
    strcpy(msg, (char*) message->payload);
    printf("Message: %s\n", msg);

    //Response for each command
    if (msg[0] == '*' && strlen(msg) > 1)
    {
        int targetTemp;
        char resp[35]; //MQTT response
        char resp_lirc[35]; //LIRC response

        //Get sensor readings
        float temp_ = MainApp::i2c_device.getTemperature();
        float curr_ = MainApp::i2c_device.getCurrent();
        if (msg[1] == 'd')
        { //down temperature
            targetTemp = (msg[2] - 48) * 10 + msg[3] - 48;
            //LIRC
            sprintf(resp_lirc, "irsend SEND_ONCE MY_REMOTE TE%d", targetTemp);
            system(resp_lirc);
            //MQTT
            sprintf(resp, "ON;%f;%d;%f;%%", temp_, targetTemp, curr_);
            printf("DOWNTEMP\n");
        }
        else if (msg[1] == 'u')
        { //up temperature
            targetTemp = (msg[2] - 48) * 10 + msg[3] - 48;
            //LIRC
            sprintf(resp_lirc, "irsend SEND_ONCE MY_REMOTE TE%d", targetTemp);
            system(resp_lirc);
            //MQTT
            sprintf(resp, "ON;%f;%d;%f;%%", temp_, targetTemp, curr_);
            printf("UPTEMP\n");
        }
        else if (msg[1] == '0')
        { //power off
            system("irsend SEND_ONCE MY_REMOTE PWOF"); //LIRC
            sprintf(resp, "OFF; ; ; ;%%");
            printf("OFF\n");
        }
        else if (msg[1] == '1')
        { //power on
            targetTemp = (msg[2] - 48) * 10 + msg[3] - 48;
            system("irsend SEND_ONCE MY_REMOTE PWON"); //LIRC
            sprintf(resp, "ON;%f;%d;%f;%%", temp_, targetTemp, curr_);

            printf("ON\n");
        }
        else if (msg[1] == 'r')
        { //read sensors
            if(msg[2] == '1')
            {
                targetTemp = (msg[3] - 48) * 10 + msg[4] - 48;
                sprintf(resp, "ON;%f;%d;%f;%%", temp_, targetTemp, curr_);
            }
            else if (msg[2] == '0')
            {
                sprintf(resp, "OFF;%f; ; ;%%", temp_);
            }
            printf("READ\n");
        }

        //Back response/acknowledge part
        int pub = mosquitto_publish(m, NULL, TOPIC, strlen(resp), resp, 0, false);
        if (pub)
        {
            printf("Can't publish message\n");
            exit(-1);
        }
    }
}


MainApp::MainApp()
{
    runFlag = false;
    ptrThread = QtConcurrent::run(this, &MainApp::execThread);
    startTimer(1000, Qt::CoarseTimer);
}


MainApp::~MainApp(){
    runFlag = false;
    ptrThread.waitForFinished();
}

void MainApp::timerEvent(QTimerEvent* e){

}


void MainApp::execThread(){
    runFlag = true;

    while(runFlag)
    {
            i2c_device = I2C();
            //Mosquitto library initialization
            struct mosquitto *m = NULL;
            mosquitto_lib_init();
                //Client initialization (NULL = random)
            m = mosquitto_new(NULL, true, NULL);
            if (!m)
            {
                printf("Can't initialize Mosquitto\n");
                exit(-1);
            }

            //Connect to server
            int conn = mosquitto_connect(m, HOST, PORT, 0);
            if (conn)
            {
                printf("Can't connect to server\n");
                exit(-1);
            }

            //Subscribe for messages
            int sub = mosquitto_subscribe(m, NULL, TOPIC, 0);
            if (sub)
            {
                printf("Cannot subscribe\n");
                exit(-1);
            }

            srand(time(NULL));
            //Locate event handler
            mosquitto_message_callback_set(m, messageArrived);

            //Loop for getting messages
            mosquitto_loop_forever(m, -1, 1);

            //Exit if needed
            mosquitto_destroy(m);
            mosquitto_lib_cleanup();
    }
}
